abstract class A
{
public static void main(String a[])
{
System.out.println("hi");
}
}