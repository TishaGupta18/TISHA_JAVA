
import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string:");
        String x=sc.nextLine();
        System.out.println("Original string: "+ x);
        System.out.println("Reverse string: "+new StringBuilder(x).reverse());
    }
}
