class Cla2{  
public static void main(String hori[]){ 
int i; 
  for(i=0;i<hori.length;i++)  
System.out.println(hori[i]);  
  }  
}  
