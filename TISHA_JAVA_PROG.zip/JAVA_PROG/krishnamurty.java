
import java.util.*;
class Myexcep extends Exception
{
 public String toString()
 {
     return ("user defined exception---not krishnamurty");
 }
}

class A
{
   void msg(int a) throws Myexcep
   {
     int temp,f,sum=0;
     temp=a;
     while(temp!=0)
     {
         f=1;
         for(int i=1;i<=temp%10;i++)
            f=f*i;
         sum=sum+f;
         temp=temp/10;
     }
       if(a==sum)
        System.out.println("krishnamurty");
       else
        throw new Myexcep();
   }

   public static void main(String args[])
   {
       int num;
       Scanner sc=new Scanner(System.in);
       System.out.println("enter num:");
       num=sc.nextInt();
       A obj= new A();
       try
       {
           obj.msg(num);
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
   }
}
