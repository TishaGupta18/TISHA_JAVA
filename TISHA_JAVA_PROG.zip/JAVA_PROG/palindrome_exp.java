import java.util.*;
class Myexcep extends Exception
{
 public String toString()
 {
     return ("user defined exception---not palindrome");
 }
}

class A
{
   void msg(int a) throws Myexcep
   {
       int temp=a,rev=0,rem=0;
       while(temp!=0)
       {
           rem=temp%10;
           rev=rev*10+rem;
           temp=temp/10;
       }

       if(rev==a)
        System.out.println("palindrome");
       else
        throw new Myexcep();
   }

   public static void main(String args[])
   {
       int num;
       Scanner sc=new Scanner(System.in);
       System.out.println("enter num:");
       num=sc.nextInt();
       A obj= new A();
       try
       {
           obj.msg(num);
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
   }
}
