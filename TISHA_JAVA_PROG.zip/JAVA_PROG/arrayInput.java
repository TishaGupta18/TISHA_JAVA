import java.util.*;
public class arrayInput {
    public static void main(String[] args) {
        //user input array for 1 d array
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1 d array");
         int size= sc.nextInt();
        int numbers[]= new int [size];
        System.out.println("enter elements of 1 d array");
        //input
         for(int i=0;i<size;i++)
          numbers[i]=sc.nextInt();
          
          //output
          System.out.println("elements of 1 d array are:");
        for(int i=0;i<size;i++)
          System.out.print(numbers[i]+" " );
         System.out.println();

          //user input for 2 d array
        System.out.println("enter number of rows of 2d array:");
        int row= sc.nextInt();
         System.out.println("enter number of columns of 2d array:");
        int col= sc.nextInt();
        int numbers1[][]= new int[row][col];
        //input
        System.out.println("enter elements of 2 d array");
         for(int i=0;i<row;i++){
            for(int j=0;j<col;j++)
               numbers1[i][j]=sc.nextInt();
         }
         
          //output
          System.out.println("elements of 2 d array are:");
          for(int i=0;i<row;i++){
            for(int j=0;j<col;j++)
               System.out.print(numbers1[i][j]+" ");
            System.out.println();
         }
          
    }
}

