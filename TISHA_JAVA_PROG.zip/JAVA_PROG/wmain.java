class A
{
static int a,b;
static
{
a=9;
b=8;

System.out.println("static block"+(a+b));
}
public static void main(String a[])
{
}
}