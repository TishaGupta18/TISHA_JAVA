import java.util.*;
public class test1 {
    public static void main(String[] args) {
        int a;
        String b;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter marks and name:");
       
        b=sc.nextLine();
        a=sc.nextInt();
        System.out.println(a);
        System.out.println(b);   
    }
}
