    int temp=arr[minIndex];
    arr[minIndex]=arr[i];
    arr[i]=temp;