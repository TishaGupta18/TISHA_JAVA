import java.util.*;
public class input {
   public static void main(String[] args) {
      //user input

   //  Scanner sc = new Scanner(System.in);
   //  int a=sc.nextInt();
   //  int b=sc.nextInt();
   //  int sum=a+b;
    Scanner sc = new Scanner(System.in);
     //String name=sc.next();   //takes only one word as input
     String name=sc.nextLine(); 
    //output
    System.out.println(name);

   // System.out.println("sum="+sum);
   //  System.out.println("Tisha");
   //  System.out.println("gupta");

   //  System.out.print("man is goood ");
   //  System.out.println("man is bad");
   }
}
