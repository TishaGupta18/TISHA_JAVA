package package3;
public class getName{
    public void getName(String s){
        System.out.println(s);
    }
}