import java.util.Scanner;

class A {
    public static String wordInLine(String sentence, String word) {
        String[] words = sentence.split(" ");
        for (String w : words) {
            if (w.equals(word)) {
                return "Yes";
            }
        }
        return "No";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a sentence:");
        String sentence = scanner.nextLine();

        System.out.println("Enter a word to search:");
        String word = scanner.nextLine();

        String result = wordInLine(sentence, word);
        System.out.println("Is the word present in the sentence? " + result);

        scanner.close();
    }
}