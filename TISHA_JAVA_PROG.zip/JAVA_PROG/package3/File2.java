package package3;

// No need to import anything as both files are in the same package

public class File2 {
    public static void main(String[] args) {
        // Create an instance of File1
        File1 file1 = new File1();
        
        // Call the method from File1
        file1.displayMessage();
    }
}
