package package3;
import java.util.*;

public class B {
    public static void main(String agrs[]) {
        A obj = new A();
        System.out.println("Enter any two number:");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        if (a > b)
            System.out.println("GCD= "+ obj.GCD(a, b));
        else
            System.out.println("GCD= "+ obj.GCD(b, a));
    }
}
