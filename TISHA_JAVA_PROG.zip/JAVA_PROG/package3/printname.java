package package3;
// import package3.getName;
 public class printname {
    public static void main(String[] args) {
        String name="nit";
        getName obj =new getName();
        obj.getName(name);
        
    }
}


