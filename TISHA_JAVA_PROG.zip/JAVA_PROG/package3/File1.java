package package3;

public class File1 {
    public void displayMessage() {
        System.out.println("Hello from File1!");
    }
}
