package package3;

public class A {
    public int GCD(int a, int b) {
        if (a == 0) return b;
        if (b == 0) return a;
        
        int m = 1;
        if (a < 0 || b < 0) {
            return -1;
        } else {
            for (int i = 1; i <= a && i <= b; i++) { 
                if (a % i == 0 && b % i == 0) {
                    m = i; 
                }
            }
            return m;
        }
    }
}