import java.util.*;
class A
{
	int a;

	void setVal(int a)
	{
		this.a = a;
	}
	void armstrong()
	{
                int rem,num,sum =0,count=0;
                num=a;
                while(num!=0)
               {
                 num=num/10;
                  ++count;
               }
                num=a;
		while (num!=0)
		{
            		rem=num % 10;
                        int power=1;
                        for(int i=1;i<=count;i++)
                           power=power*rem;
            		sum += power;
            		num /= 10;
		}
	if(sum == a)
            System.out.println(a+" is an Armstrong number");
        else
            System.out.println(a+" is not an Armstrong number");
	}
}

class Demo
{
	public static void main(String args[])
	{
		A x = new A();
		Scanner sc=new Scanner(System.in);
		x.setVal(sc.nextInt());
		x.armstrong();
	}
}
