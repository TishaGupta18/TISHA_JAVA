import java.util.*;
class A
{

    public static void insertion_sort(int arr[])
    {
       int k;
       for(k=1;k<arr.length;k++)
       {
           int j=k-1;
           int temp=arr[k];
           while(j>arr[k]&&j>=0)
           {
               arr[j+1]=arr[j];
               j--;
           }
           arr[j+1]=temp;
       }
    }


	 public static void main(String[] args)
	 {
     	  Scanner sc=new Scanner(System.in);

	  System.out.println("enter size of array");
	  int size= sc.nextInt();
          int arr[]= new int [size];
 	  System.out.println("enter elements of array");

          for(int i=0;i<arr.length;i++)
          	arr[i]=sc.nextInt();

           System.out.println("elements of array are:");
          for(int i=0;i<arr.length;i++)
         	 System.out.println(arr[i]+" " );
          System.out.println("elements of sorted array are:");

          insertion_sort(arr);

         for(int i=0;i<arr.length;i++)
          	System.out.println(arr[i]+" " );
   	 }
}
