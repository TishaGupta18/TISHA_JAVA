class A
{
public static void main(String args[])
{
int a,b;
a=12;
b=34;
System.out.println("addition of "+a+" and "+b+" is "+(a+b));
}
}