import java.util.*;

class noPrime extends Exception {
    public noPrime(String message) {
        super(message);
    }
}

class primesir {
    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("size ");
        int n = scanner.nextInt();

        int[] array = new int[n];
        System.out.println("elements ->");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        System.out.println("Answets");
        for (int num : array) {
            try {
                if (isPrime(num)) {
                    System.out.println(num + " is Prime");
                } else {
                    throw new noPrime(num + " is not Prime");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }


}
