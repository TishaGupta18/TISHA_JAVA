import java.util.*;
class A
{
	public static void main(String args[])
	{
		String s,m;
		int i;
		Scanner sc=new Scanner(System.in);
		s=sc.nextLine();
		m=sc.nextLine();
		if(s.length()!=m.length())
		{
			System.out.println("Not same:");
		}
		else
		{
			for(i=0;i<s.length();i++)
			{
				if(s.charAt(i)!=m.charAt(i))
				{
					break;
				}
			}
			if(i>=s.length())
			{
				System.out.println("Same");
			}
			else
			{
				System.out.println("Not same:");
			}
		}
	}
}
