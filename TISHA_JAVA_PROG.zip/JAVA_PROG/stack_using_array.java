import java.util.*;
class A{
    int arr[];
    int top=-1;
    int size;

    A(int size)
    {
       this.size=size;
       this.arr=new int[size];
    }

    void push(int item)
    {
       if(top==size-1)
            System.out.println("overflow");
       else
       {
           top++;
           arr[top]=item;
           System.out.println(arr[top]+" pushed into the stack");
       }
    }

    void pop()
    {
        if(top==-1)
            System.out.println("underflow");
        else
        {
            System.out.println(arr[top]+" is to be poped");
            top--;
        }
    }

    void peek()
    {
        if(top==-1)
            System.out.println("underflow");
        else
        {
            System.out.println(arr[top]+" is the topmost element");
        }
    }

    void display()
    {
         if(top==-1)
            System.out.println("underflow");
         else
         {
             System.out.println("Elements of stack are: ");
             for(int i=top;i>=0;i--)
                 System.out.print(arr[i]+"    ");
         }
    }

    public static void main (String args[])
    {
        Scanner sc=new Scanner(System.in);
        A obj= new A(5);
        while(true)
        {
            System.out.println("PRESS 1 TO PUSH\nPRESS 2 TO POP\nPRESS 3 TO PEEK\nPRESS 4 TO DISPLAY\nPRESS 5 TO EXIT\n");
            int ch=sc.nextInt();
            System.out.println("---------------------------------------------------------------------------------------------");
            switch(ch)
            {
                case 1:System.out.print("Enter item: ");
                       int item=sc.nextInt();
                       obj.push(item);
                       break;
                case 2:obj.pop();
                       break;
                case 3:obj.peek();
                       break;
                case 4:obj.display();
                       break;
                case 5:System.exit(0);
                default:
                    System.out.print("wrong choice");
            }
        }
    }
}
