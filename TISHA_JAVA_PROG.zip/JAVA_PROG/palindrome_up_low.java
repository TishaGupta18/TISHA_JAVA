import java.util.*;

class A
{
   void palindrome(int lb,int ub)
   {
       int count=0;
       for(int i=lb;i<=ub;i++)
       {
           int temp,rev=0,rem=0;
           temp=i;
           while(temp!=0)
           {
               rem=temp%10;
               rev=rev*10+rem;
               temp=temp/10;
           }

           if(rev==i)
           {
              System.out.println(i);
              count++;
           }

       }
       System.out.println("count="+count);
   }

   public static void main(String args[])
   {
       int lb,ub;
       Scanner sc=new Scanner(System.in);
       System.out.println("enter lb:");
       lb=sc.nextInt();
       System.out.println("enter ub:");
       ub=sc.nextInt();
       A obj= new A();
       obj.palindrome(lb,ub);
   }
}

