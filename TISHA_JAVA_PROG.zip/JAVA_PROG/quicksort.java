import java.util.*;
class A
{
	static int partition(int arr[],int beg,int end)
	{
 		int left,right,loc,flag=0;
		left=beg;right=end;loc=beg;
		while(flag==0)
		{
			while(arr[loc]<=arr[right]&&loc!=right)
				right--;
			if(loc==right)
				flag=1;
			else if(arr[loc]>arr[right])
			{
				arr[loc]=arr[loc]^arr[right];
				arr[right]=arr[loc]^arr[right];
				arr[loc]=arr[loc]^arr[right];
				loc=right;
			}
			if(flag==0)
			{
			  	while(arr[loc]>=arr[left]&&loc!=left)
				left++;
			if(loc==left)
				flag=1;
			else if(arr[loc]<arr[left])
			{
				arr[loc]=arr[loc]^arr[left];
				arr[left]=arr[loc]^arr[left];
				arr[loc]=arr[loc]^arr[left];
				loc=left;
			}
			}
		}
	    return loc;
	}

    static void quicksort(int arr[],int beg,int end)
	{
		if(beg<end)
		{
			int pivot=partition(arr,beg,end);
			quicksort(arr,beg,pivot-1);
			quicksort(arr,pivot+1,end);

		}
	}

	 public static void main(String[] args)
	 {
      Scanner sc=new Scanner(System.in);

	  System.out.println("enter size of array");
	  int size= sc.nextInt();
          int arr[]= new int [size];
 	  System.out.println("enter elements of array");

      for(int i=0;i<arr.length;i++)
          	arr[i]=sc.nextInt();
     System.out.println("elements of array are:");
     for(int i=0;i<arr.length;i++)
         	 System.out.println(arr[i]+" " );
     System.out.println("elements of sorted array are:");

     quicksort(arr,0,arr.length-1);

     for(int i=0;i<arr.length;i++)
          	System.out.println(arr[i]+" " );
   	 }
}
