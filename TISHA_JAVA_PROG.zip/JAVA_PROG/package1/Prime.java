
class A
{
public int prime(int n)
{
int i;
for(i=2; i<=n/2; i++)
{
if(n%i==0)
break;
}
if(n==1 || i<=n/2)
return 0;
else
return 1;
}
}
