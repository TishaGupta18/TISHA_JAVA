

import java.util.*;
class A
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first string:");
        String x=sc.nextLine();
        System.out.println("Enter second string:");
        String y=sc.nextLine();
        if(x.equals(y))
        {
            System.out.println("same");
        }
        else
        {
            System.out.println("diff");
        }

    }
}
