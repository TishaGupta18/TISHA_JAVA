import java.util.*;

public class sorting_algo {
//print array 
    public static void PrintArray(int arr[],int size){
        for(int i=0;i<size;i++)
          System.out.print(arr[i]+" " );
         System.out.println();  
}
//selelction sort complexity O(n^2)
 public static void selectionSort(int arr[],int size){
    for(int i=0;i<size-1;i++){
      int minIndex=i;
      for(int j=i+1;j<size;j++){
        if(arr[j]<arr[minIndex]){
            minIndex=j;
        }
      }
    int temp=arr[minIndex];
    arr[minIndex]=arr[i];
    arr[i]=temp;
    } 
}
//bubble sort complexity O(n^2)
public static void bubbleSort(int arr[],int size){
  for(int i=0;i<size-1;i++){
    for(int j=0;j<size-i-1;j++){
      if(arr[j]<arr[j+1])
      {
        arr[j]=arr[j]^arr[j+1];
        arr[j+1]=arr[j]^arr[j+1];
        arr[j]=arr[j]^arr[j+1];
      }     
  } 
 }
}
//insertion sort
// complexity O(n^2)~~~~~~~~~~~avg and worst case
//complexity O(n)~~~~~~~~~~~best case
public static void insertionSort(int arr[],int size){
 for(int i=1;i<size;i++){
  int j=i-1;
  int temp=arr[i];
  while(j>=0 && arr[j]>temp){
     arr[j+1]=arr[j];
     j--;
  }
  arr[j+1]=temp;
 }
}

//quick sort
// complexity O(nlogn)~~~~~~~~~~~avg and best case
//complexity O(n^2)~~~~~~~~~~~worst case  when pivot is smallest or largest element


public static int partition1(int arr[],int lb,int ub)
{
    int pivot=arr[ub];
    int i=lb-1;// i points to last number less than pivot

    for(int j=lb;j<ub;j++)
    {
        if(arr[j]<pivot)
        {
            i++;
            arr[i]=arr[i]^arr[j];
            arr[j]=arr[i]^arr[j];
            arr[i]=arr[i]^arr[j];
            
        }
    }
    arr[i+1]=arr[i+1]^arr[ub];// i+1 pr pivot ka shi position hai
    arr[i]=arr[i+1]^arr[ub];
    arr[i+1]=arr[i+1]^arr[ub];
    return i+1;
}
public static void quickSort(int arr[],int lb,int ub){
  if(lb<ub)
  {
     int loc=partition1(arr,lb,ub);
      quickSort(arr,lb,loc-1);
      quickSort(arr,loc+1,ub);
  }

}
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of array");
         int size= sc.nextInt();
        int arr[]= new int [size];
        System.out.println("enter elements of array");
        //input
         for(int i=0;i<size;i++)
          arr[i]=sc.nextInt();

          System.out.println("elements of array are:");
          PrintArray(arr,size);
          System.out.println("elements of sorted array are:");
          //selectionSort(arr,size);
         // bubbleSort(arr,size);
          // insertionSort(arr,size);
          quickSort(arr,0,size-1);
          PrintArray(arr,size);
    }

}
