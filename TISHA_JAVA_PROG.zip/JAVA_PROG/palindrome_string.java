import java.util.*;

class A
{
   void msg(String str)
   {
    int i,j;
    j=str.length()-1;
    for(i=0;i<=j;i++,j--)
    {
        if(str.charAt(i)!=str.charAt(j))
            break;
    }
       if(i>j)
        System.out.println("palindrome");
       else
        throw new ArithmeticException();
   }

   public static void main(String args[])
   {
       String str;
       Scanner sc=new Scanner(System.in);
       System.out.println("enter string:");
       str=sc.nextLine();
       A obj= new A();
       try
       {
           obj.msg(str);
       }
       catch(Exception e)
       {
           System.out.println("not palindrome--"+e);
       }
   }
}
