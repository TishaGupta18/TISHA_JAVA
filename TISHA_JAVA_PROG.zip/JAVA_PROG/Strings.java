import java.util.Scanner;

public class Strings {
    public static void main(String[] args) {
        //string declaration
        // String name="tisha";
        // String fullname="tisha gupta";
         String sentence="my name is tissha";

        //user input
        // Scanner sc = new Scanner(System.in);
        // //String name= sc.next(); //tisha gupta
        // //System.out.println(name);//tisha
        // String name1= sc.nextLine(); //tisha gupta
        // System.out.println("my name is "+name1);//tisha gupta

      // cocncatenation of two string
      String first="Tisha";
      String second ="Gupta";
      String full=first+second;
      System.out.println(full);

      //calculate length of string
      System.out.println(full.length());
      //print individual character using charAt()
      for(int i=0;i<full.length();i++)
        System.out.println(full.charAt(i));

        //compare two string
        if (first.compareTo(second)==0)
          System.out.println("equal");
        else
          System.out.println("not equal");
        
        //extract a string
        String find=sentence.substring(3,7);
        System.out.println(find);
        System.out.println(sentence.substring(3,sentence.length()));

         
    }
}
