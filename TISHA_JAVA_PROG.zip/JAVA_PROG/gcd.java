import java.util.*;
class Myexcep extends Exception
{
 public String toString()
 {
     return ("user defined exception---negative number not allowed");
 }
}

class A
{
   void gcd(int a,int b) throws Myexcep
   {
       int i;
       int p=0;
       if(a<0||b<0)
           throw new Myexcep();
       else
       {
            for (i=1;i<=a&&i<=b;i++)
            {
                if(a%i==0&&b%i==0)
                   p=i;
            }
            System.out.println(p);
       }

   }

   public static void main(String args[])
   {
       int num1,num2;
       Scanner sc=new Scanner(System.in);
       System.out.println("enter two num whose gcd you want:");
       num1=sc.nextInt();
       num2=sc.nextInt();
       A obj= new A();
       try
       {
           obj.gcd(num1,num2);
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
   }
}

