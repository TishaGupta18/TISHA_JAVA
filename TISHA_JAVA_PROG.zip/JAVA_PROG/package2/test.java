
import java.util.*;
import package1.*;
class test
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
A ob=new A();
int x=sc.nextInt();
if(ob.prime(x)==1)
System.out.println("Prime");
else
System.out.println("Not Prime");
}
}
